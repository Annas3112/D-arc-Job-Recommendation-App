package com.id.darc.ui.screen.company

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.id.darc.data.Resource
import com.id.darc.repository.irepository.IJobRepository
import com.id.darc.repository.model.company.CompanyDetailModel
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject


/*
   Created by Andre Eka Putra on 27/12/23
   andremoore431@gmail.com
*/

@HiltViewModel
class VacancyViewModel @Inject constructor(
    private val jobRepository: IJobRepository
): ViewModel() {
    val _uiState = MutableStateFlow(VacancyUIState())
    val uiState: StateFlow<VacancyUIState> = _uiState.asStateFlow()

    fun jobRepository(id: Int) {
        viewModelScope.launch {
            jobRepository.fetchDetailCompany(id).collect {res ->
                when (res) {
                    is Resource.Success -> {
                        _uiState.update {
                            it.copy(
                                data = res.data ?: CompanyDetailModel.emptyData()
                            )
                        }
                    }
                    else -> {}
                }
            }
        }
    }
}

data class VacancyUIState(
    val data: CompanyDetailModel = CompanyDetailModel.emptyData()
)