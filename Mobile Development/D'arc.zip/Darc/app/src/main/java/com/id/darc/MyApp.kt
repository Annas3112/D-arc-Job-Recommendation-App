package com.id.darc

import android.app.Application
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.HiltAndroidApp


/*
   Created by Andre Eka Putra on 20/12/23
   andremoore431@gmail.com
*/

@HiltAndroidApp
class MyApp: Application() {
}