package com.id.darc.repository.model.company

import kotlin.random.Random


/*
   Created by Andre Eka Putra on 12/12/23
   andremoore431@gmail.com
*/

data class CompanyModel(
    val profilePicture: String,
    val name: String,
    val position: String,
    val location: String,
    val requirement: String,
    val salary: String,
    val bookmark: Boolean = false
) {
    companion object {
        val fakes = List(10) {
            CompanyModel(
                profilePicture = "https://example.com/profile_picture_${Random.nextInt(100)}.png",
                name = "Company ${Random.nextInt(1000)}",
                position = "Software Engineer",
                location = "City ${Random.nextInt(10)}",
                requirement = "Bachelor's degree in Computer Science",
                salary = "$${Random.nextInt(50000, 100000)}"
            )
        }
    }
}
