package com.id.darc.ui.screen.profile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.id.darc.data.auth.AuthRepository
import com.id.darc.repository.irepository.IAuthRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject


/*
   Created by Andre Eka Putra on 21/12/23
   andremoore431@gmail.com
*/

@HiltViewModel
class ProfileViewModel @Inject constructor(
    private val authRepository: IAuthRepository
): ViewModel() {
    fun logout() {
        viewModelScope.launch {
            authRepository.logout()
        }
    }
}