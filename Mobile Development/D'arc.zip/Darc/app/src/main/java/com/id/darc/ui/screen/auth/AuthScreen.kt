package com.id.darc.ui.screen.auth;

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.id.darc.R
import com.id.darc.ui.component.button.PrimaryButton
import com.id.darc.ui.theme.DarcTheme
import com.id.darc.ui.theme.white


/*
   Created by Andre Eka Putra on 05/12/23
   andremoore431@gmail.com
*/


@Composable
fun AuthScreen(
    modifier: Modifier = Modifier,
    navigateToRegister: () -> Unit = {},
    navigateToLogin: () -> Unit = {},
) {
    Column(
        modifier = modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Image(
            modifier = Modifier.size(130.dp, 150.dp),
            painter = painterResource(id = R.drawable.darc_logo),
            contentDescription = "")
        PrimaryButton(text  = "SIGN UP",
            modifier = Modifier.padding(top = 50.dp)
        ) {
            navigateToRegister()
        }
        PrimaryButton(text = "LOGIN",
            modifier = Modifier.padding(top = 30.dp)
        ) {
            navigateToLogin()
        }
    }
}

@Composable
@Preview
fun ShowAuthScreenPreview() {
    DarcTheme {
        AuthScreen()
    }
}
