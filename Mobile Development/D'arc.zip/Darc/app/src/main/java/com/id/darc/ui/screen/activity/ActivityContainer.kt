package com.id.darc.ui.screen.activity;

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.id.darc.repository.model.company.CompanyModel
import com.id.darc.ui.screen.company.CompanyScreen
import com.id.darc.ui.screen.company.DetailScreen
import com.id.darc.ui.theme.DarcTheme


/*
   Created by Andre Eka Putra on 21/12/23
   andremoore431@gmail.com
*/


@Composable
fun ActivityContainer(
    modifier: Modifier = Modifier
) {
    var state by remember { mutableIntStateOf(0) }
    val titles = listOf("Saved", "Applied")

    val dummyCompanyData = CompanyModel.fakes

    Column(
        modifier = modifier
    ) {
        TabRow(selectedTabIndex = state, modifier = Modifier.padding(bottom = 20.dp)) {
            titles.forEachIndexed { index, title ->
                Tab(
                    selected = state == index,
                    onClick = { state = index },
                    text = { Text(text = title, maxLines = 2, overflow = TextOverflow.Ellipsis) }
                )
            }
        }
        when (state) {
            0 -> SavedScreen()
            1 -> AppliedScreen()
        }
    }
}

@Composable
@Preview
fun ShowActivityContainerPreview() {
    DarcTheme {
        ActivityContainer()
    }
}
