package com.id.darc.ui.screen.home

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.id.darc.data.Resource
import com.id.darc.repository.irepository.IJobRepository
import com.id.darc.repository.model.company.CompanyModel
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject


/*
   Created by Andre Eka Putra on 26/12/23
   andremoore431@gmail.com
*/

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val repository: IJobRepository
): ViewModel() {
    val _uiState = MutableStateFlow(HomeUIState())
    val uiState: StateFlow<HomeUIState> = _uiState.asStateFlow()

    init {
        fetchJobs()
    }

    fun fetchJobs() {
        viewModelScope.launch {
            repository.fetchCompanies().collect {res ->
                when (res) {
                    is Resource.Error -> {
                        _uiState.update {
                            it.copy(
                                isError = true,
                                errorMessage = res.message.toString()
                            )
                        }
                    }
                    is Resource.Loading -> {}
                    is Resource.Success -> {
                        _uiState.update {
                            it.copy(
                                isSuccess = true,
                                listJob = res.data ?: listOf()
                            )
                        }
                    }
                }
            }
        }
    }


    fun search(query: String){
        viewModelScope.launch {
            repository.searchCompany(query).collect {res ->
                when (res) {
                    is Resource.Error -> {
                        _uiState.update {
                            it.copy(
                                isError = true,
                                errorMessage = res.message.toString()
                            )
                        }
                    }
                    is Resource.Loading -> {}
                    is Resource.Success -> {
                        _uiState.update {
                            it.copy(
                                isSuccess = true,
                                searchData = res.data ?: CompanyModel.emptyData
                            )
                        }
                    }
                }
            }
        }
    }
}

data class HomeUIState(
    val isSuccess: Boolean = false,
    val isError: Boolean = false,
    val errorMessage: String = "",

    val searchData: CompanyModel = CompanyModel(
        profilePicture = "",
        name = "",
        position = "",
        location = "",
        requirement = "",
        salary = "",
        bookmark = false
    ),
    val listJob: List<CompanyModel> = listOf(),
)