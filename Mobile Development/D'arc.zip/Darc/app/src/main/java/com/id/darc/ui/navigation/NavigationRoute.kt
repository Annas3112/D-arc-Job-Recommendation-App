package com.id.darc.ui.navigation

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavType
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import androidx.navigation.navigation
import com.id.darc.R
import com.id.darc.ui.screen.activity.ActivityContainer
import com.id.darc.ui.screen.company.VacancyContainer
import com.id.darc.ui.screen.home.HomeContainer
import com.id.darc.ui.screen.home.HomeScreen
import com.id.darc.ui.screen.notification.NotificationContainer
import com.id.darc.ui.screen.profile.ProfileScreen
import com.id.darc.ui.screen.recommend.RecommendScreen
import com.id.darc.ui.theme.Typography


/*
   Created by Andre Eka Putra on 21/12/23
   andremoore431@gmail.com
*/

sealed class NavigationRoute (val route: String) {
    object HomeContainer: NavigationRoute("homeContainer")
    object VacancyDetailContainer: NavigationRoute("vacancyContainer")
    object NotificationContainer: NavigationRoute("notificationContainer")
}

@OptIn(ExperimentalMaterial3Api::class)
fun NavGraphBuilder.homeGraph(navController: NavController) {
    navigation(startDestination = NavigationRoute.HomeContainer.route, route = "homeRoute") {
        composable(NavigationRoute.HomeContainer.route) {
            val currentScreen = remember { mutableStateOf(HomeContainer.Home) }
            Scaffold(
                modifier = Modifier.background(Color.LightGray),
                topBar = {
                    TopAppBar(
                        title = {
                            Text(
                                modifier = Modifier.fillMaxWidth(),
                                text = currentScreen.value.title, style = Typography.titleLarge, textAlign = TextAlign.Center)
                        },
                        actions = {
                            Icon(imageVector = Icons.Default.Notifications, contentDescription = null, modifier = Modifier.clickable {
                                navController.navigate(NavigationRoute.NotificationContainer.route)
                            })
                        }
                    )
                },
                bottomBar = {
                    NavigationBar {
                        NavigationBarItem(
                            icon = { Icon(imageVector = Icons.Default.Home, contentDescription = null) },
                            label = { Text("Home") },
                            selected = currentScreen.value == HomeContainer.Home,
                            onClick = {
                                currentScreen.value = HomeContainer.Home
                            }
                        )
                        NavigationBarItem(
                            icon = { Icon(imageVector = Icons.Default.ThumbUp, contentDescription = null) },
                            label = { Text("Recommend") },
                            selected = currentScreen.value == HomeContainer.Recommendations,
                            onClick = {
                                currentScreen.value = HomeContainer.Recommendations
                            }
                        )
                        NavigationBarItem(
                            icon = {
                                Icon(
                                    modifier = Modifier.size(23.dp),
                                    painter = painterResource(id = R.drawable.bookmark_filled),
                                    contentDescription = null)
                            },
                            label = { Text("Activity") },
                            selected = currentScreen.value == HomeContainer.Activity,
                            onClick = {
                                currentScreen.value = HomeContainer.Activity
                            }
                        )
                        NavigationBarItem(
                            icon = { Icon(imageVector = Icons.Default.Person, contentDescription = null) },
                            label = { Text("Profile") },
                            selected = currentScreen.value == HomeContainer.Profile,
                            onClick = {
                                currentScreen.value = HomeContainer.Profile
                            }
                        )
                    }
                }
            ) {
                Column(
                    modifier = Modifier
                        .padding(it)
                        .background(Color.LightGray)
                ) {
                    Column {
                        when (currentScreen.value) {
                            HomeContainer.Home ->  HomeScreen(navigateToDetail = {
                                navController.navigate("${NavigationRoute.VacancyDetailContainer.route}/$it")
                            })
                            HomeContainer.Recommendations -> RecommendScreen()
                            HomeContainer.Activity -> ActivityContainer()
                            HomeContainer.Profile -> ProfileScreen()
                        }
                    }
                }
            }
        }
        composable("${NavigationRoute.VacancyDetailContainer.route}/{index}",
            arguments = listOf(navArgument("index") { type = NavType.IntType })) {
            VacancyContainer(backNavigation = {navController.popBackStack()}, itemIndex = it.arguments?.getInt("index") ?: 0)
        }
        composable(NavigationRoute.NotificationContainer.route) {
            NotificationContainer(backNavigation = {navController.popBackStack()})
        }
    }
}