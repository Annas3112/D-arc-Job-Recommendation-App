package com.id.darc.di.job

import com.id.darc.BuildConfig
import com.id.darc.data.job.source.JobApiService
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory


/*
   Created by Andre Eka Putra on 22/12/23
   andremoore431@gmail.com
*/

@Module
@InstallIn(SingletonComponent::class)
class JobNetworkModule {
    @Provides
    fun provideAuthApiService(client: OkHttpClient): JobApiService {
        val retrofit = Retrofit.Builder()
            .baseUrl(BuildConfig.BASE_API_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .client(client)
            .build()
        return retrofit.create(JobApiService::class.java)
    }
}