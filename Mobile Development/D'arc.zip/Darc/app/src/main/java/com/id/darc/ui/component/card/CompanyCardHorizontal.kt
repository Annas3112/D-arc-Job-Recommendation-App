package com.id.darc.ui.component.card;

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.id.darc.R
import com.id.darc.repository.model.company.CompanyModel
import com.id.darc.ui.theme.DarcTheme
import com.id.darc.ui.theme.Typography


/*
   Created by Andre Eka Putra on 12/12/23
   andremoore431@gmail.com
*/


@Composable
fun CompanyCardHorizontal(
    modifier: Modifier = Modifier,
    bookmark: Boolean = false,
    companyProfile: CompanyModel
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .size(250.dp)
            .background(Color.White)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                AsyncImage(
                    model = "",
                    placeholder = painterResource(R.drawable.pertamina_dummy_picture),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(50.dp)
                        .clip(RoundedCornerShape(5.dp))
                )
                Text(text = companyProfile.name,
                    modifier = Modifier.padding(start = 5.dp),
                    style = Typography.titleMedium)
            }
            Column {
                Text(text = "Position:",
                    style = Typography.titleSmall
                )
                Text(text = companyProfile.position, style = Typography.bodyMedium)
            }

            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Image(imageVector = Icons.Default.LocationOn,
                    modifier = Modifier.size(15.dp),
                    contentDescription = null)
                Text(text = companyProfile.location, style = Typography.titleSmall)
            }
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Image(imageVector = Icons.Default.LocationOn,
                    modifier = Modifier.size(15.dp),
                    contentDescription = null)
                Text(text = companyProfile.requirement, style = Typography.titleSmall)
            }
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Image(painter = painterResource(id = R.drawable.dollar_icon),
                    modifier = Modifier.size(15.dp),
                    contentDescription = null)
                Text(text = companyProfile.salary, style = Typography.titleSmall)
            }
            Row {
                Spacer(modifier = Modifier.weight(1f))
                Image(
                    painter = painterResource(id =
                        if (bookmark) R.drawable.bookmark_filled else R.drawable.bookmark_unfilled
                    ),
                    modifier = Modifier.size(25.dp),
                    contentDescription = null)
            }
        }
    }
}

@Composable
@Preview
fun ShowCompanyCardHorizontalPreview() {
    DarcTheme {
        CompanyCardHorizontal(
            companyProfile = CompanyModel(
                profilePicture = "blandit",
                name = "PT Pertamina (Persero)",
                position = "Auditor Group IT Internal Audit (PWTT)",
                location = "Jakarta Pusat, DKI Jakarta",
                requirement = "Minimum S1",
                salary = "Rp 10.000.000 /month"
            )
        )
    }
}
