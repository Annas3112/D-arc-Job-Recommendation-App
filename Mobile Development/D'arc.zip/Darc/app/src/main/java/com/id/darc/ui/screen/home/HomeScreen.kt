package com.id.darc.ui.screen.home;

import android.util.Log
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.id.darc.repository.model.company.CompanyModel
import com.id.darc.ui.component.card.CompanyCardHorizontal
import com.id.darc.ui.component.card.CompanyCardVertical
import com.id.darc.ui.component.field.InputTextFieldLeading
import com.id.darc.ui.theme.DarcTheme
import com.id.darc.ui.theme.Typography


/*
   Created by Andre Eka Putra on 13/12/23
   andremoore431@gmail.com
*/


@Composable
fun HomeScreen(
    modifier: Modifier = Modifier,
    navigateToDetail: (Int) -> Unit = {}
) {
    val viewModel: HomeViewModel = hiltViewModel()
    val uiState = viewModel.uiState.collectAsStateWithLifecycle()
    val dummyCompanyData = CompanyModel.fakes
    val searchInput = remember { mutableStateOf("") }

    LaunchedEffect(key1 = searchInput.value) {
        viewModel.search(searchInput.value)
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(15.dp)
    ) {
        InputTextFieldLeading(
            modifier = Modifier
                .padding(horizontal = 20.dp)
                .padding(top = 20.dp),
            text = "Search Job",
            value = searchInput.value,
            onValueChange = {
                searchInput.value = it
            }
        )
        if (searchInput.value.isNotEmpty()) {
            Text(text = "Search Result",
                style = Typography.titleLarge,
                modifier = Modifier
                    .padding(top = 15.dp)
                    .padding(horizontal = 20.dp)
            )
            if (uiState.value.isSuccess) {
                CompanyCardVertical(companyProfile = uiState.value.searchData)
                
            } else if (uiState.value.isError) {
                Text(text = uiState.value.errorMessage,
                    style = Typography.bodyLarge,
                    modifier = Modifier
                        .padding(top = 15.dp)
                        .padding(horizontal = 20.dp)
                )
            }
        } else {
            Text(text = "Selected Vacancies",
                style = Typography.titleLarge,
                modifier = Modifier
                    .padding(top = 15.dp)
                    .padding(horizontal = 20.dp)
            )
            LazyRow(
                modifier = Modifier,
                contentPadding = PaddingValues(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                itemsIndexed(uiState.value.listJob){index, item ->
                    CompanyCardHorizontal(companyProfile = item, modifier = Modifier.clickable {
                        navigateToDetail(index)
                    })
                }
            }
            Text(text = "Job Vacancy Recommendations",
                style = Typography.titleLarge, modifier = Modifier
                    .padding(top = 15.dp)
                    .padding(horizontal = 20.dp)
            )
            LazyRow(
                modifier = Modifier,
                contentPadding = PaddingValues(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                itemsIndexed(uiState.value.listJob){index, item ->
                    CompanyCardHorizontal(companyProfile = item, modifier = Modifier.clickable {
                        navigateToDetail(index)
                    })
                }
            }
        }
    }
}

@Composable
@Preview(showSystemUi = true)
fun ShowHomeScreenPreview() {
    DarcTheme {
        HomeScreen()
    }
}
