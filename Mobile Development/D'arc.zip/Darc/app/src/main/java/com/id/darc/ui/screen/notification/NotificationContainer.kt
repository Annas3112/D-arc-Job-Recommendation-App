package com.id.darc.ui.screen.notification;

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.id.darc.ui.theme.DarcTheme
import com.id.darc.ui.theme.Typography


/*
   Created by Andre Eka Putra on 22/12/23
   andremoore431@gmail.com
*/


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationContainer(
    modifier: Modifier = Modifier,
    backNavigation: () -> Unit = {}
) {
    Scaffold(
        modifier = Modifier.background(Color.LightGray),
        topBar = {
            TopAppBar(
                title = {
                    Text(text ="Notification", style = Typography.titleLarge)
                },
                navigationIcon = {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = null, modifier = Modifier
                        .padding(20.dp)
                        .clickable {
                            backNavigation()
                        })
                }
            )
        }
    ) { innerPadding ->
        Column(modifier = Modifier.padding(innerPadding).padding(20.dp)) {
            Text(text = "Increase Your Job Opportunities! complete the data on your profile now!", style = Typography.titleMedium)
        }
    }
}

@Composable
@Preview
fun ShowNotificationContainerPreview() {
    DarcTheme {
        NotificationContainer()
    }
}
