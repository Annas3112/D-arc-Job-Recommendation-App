package com.id.darc.data.job.response

import com.google.gson.annotations.SerializedName

data class SearchCompanyDataResponse(
    @SerializedName("company_name")
    val companyName: String
)