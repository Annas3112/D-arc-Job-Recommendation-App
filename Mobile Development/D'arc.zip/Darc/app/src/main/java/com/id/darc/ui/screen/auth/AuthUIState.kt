package com.id.darc.ui.screen.auth

import kotlinx.coroutines.flow.update


/*
   Created by Andre Eka Putra on 20/12/23
   andremoore431@gmail.com
*/

data class AuthUIState(
    val isError: Boolean = false,
    val isSuccess: Boolean = false,
    val message: String = ""
)

fun AuthViewModel.handleError(message: String) {
    _uiState.update {
        it.copy(
            isError = true,
            message = message
        )
    }
}

fun AuthViewModel.handleSuccess() {
    _uiState.update {
        it.copy(
            isError = false,
            isSuccess = true
        )
    }
}