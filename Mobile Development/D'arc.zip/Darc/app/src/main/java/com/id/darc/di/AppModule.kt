package com.id.darc.di

import com.id.darc.data.auth.AuthRepository
import com.id.darc.data.job.JobRepository
import com.id.darc.repository.irepository.IAuthRepository
import com.id.darc.repository.irepository.IJobRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ViewModelComponent
import dagger.hilt.android.scopes.ViewModelScoped


/*
   Created by Andre Eka Putra on 20/12/23
   andremoore431@gmail.com
*/

@Module
@InstallIn(ViewModelComponent::class)
abstract class AppModule {
    @Binds
    @ViewModelScoped
    abstract fun provideAuthRepository(authRepository: AuthRepository): IAuthRepository

    @Binds
    @ViewModelScoped
    abstract fun provideJobRepository(jobRepository: JobRepository): IJobRepository
}