package com.id.darc.ui.screen.auth.login;

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.id.darc.R
import com.id.darc.ui.component.button.PrimaryButton
import com.id.darc.ui.component.field.InputTextField
import com.id.darc.ui.screen.auth.AuthViewModel
import com.id.darc.ui.theme.DarcTheme
import com.id.darc.ui.theme.primaryColor


/*
   Created by Andre Eka Putra on 05/12/23
   andremoore431@gmail.com
*/


@Composable
fun LoginScreen(
    modifier: Modifier = Modifier,
    viewModel: AuthViewModel = hiltViewModel(),
    onBackListener: () -> Unit = {},
    navigateToRegister: () -> Unit = {}
) {
    val email = remember { mutableStateOf("") }
    val password = remember { mutableStateOf("") }
    val uiState = viewModel.uiState.collectAsStateWithLifecycle()

    Column {
        Icon(
            modifier = Modifier.clickable { onBackListener() },
            imageVector = Icons.Default.ArrowBack,
            contentDescription = ""
        )
        Column(
            modifier = modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Spacer(modifier = Modifier.padding(50.dp))
            Text(text = "LOG IN", color = primaryColor,
                fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.padding(30.dp))
            InputTextField(hint = "Username", value = email.value) {
                email.value = it
            }
            Spacer(modifier = Modifier.padding(20.dp))
            InputTextField(hint = "Password", value = password.value, hideValue = true) {
                password.value = it
            }
            Spacer(modifier = Modifier.padding(30.dp))
            PrimaryButton(
                text = "LOG IN",
            ) {
                viewModel.login(email = email.value, password = password.value)
            }
            Spacer(modifier = Modifier.padding(30.dp))
            Row {
                Spacer(modifier = Modifier.weight(1f))
                Text(text = "SIGN UP", modifier = Modifier.clickable {
                    navigateToRegister()
                })
            }
            Spacer(modifier = Modifier.weight(1f))
            Image(
                modifier = Modifier.size(70.dp, 90.dp),
                painter = painterResource(id = R.drawable.darc_logo),
                contentDescription = "")
        }
    }
}

@Composable
@Preview(showSystemUi = true)
fun ShowLoginScreenPreview() {
    DarcTheme {
        LoginScreen()
    }
}
