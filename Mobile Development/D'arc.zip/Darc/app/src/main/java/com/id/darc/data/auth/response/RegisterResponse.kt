package com.id.darc.data.auth.response

data class RegisterResponse(
    val isError: Boolean,
    val message: String
)
