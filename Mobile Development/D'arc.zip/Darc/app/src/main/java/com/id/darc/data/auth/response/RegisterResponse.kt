package com.id.darc.data.auth.response


/*
   Created by Andre Eka Putra on 20/12/23
   andremoore431@gmail.com
*/

data class RegisterResponse(
    val isError: Boolean,
    val message: String
)
