package com.id.darc.data.job.response

import com.google.gson.annotations.SerializedName

data class CompanyDataResponse(
    @SerializedName("job_status")
    val jobStatus: String,
    @SerializedName("max_salary")
    val maxSalary: Float,
    @SerializedName("skillset")
    val skillSet: String,
    @SerializedName("education")
    val education: String,
    @SerializedName("job_desc")
    val jobDesc: String,
    @SerializedName("work_exp")
    val workExp: String,
    @SerializedName("min_salary")
    val minSalary: Float,
    @SerializedName("company")
    val company: String,
    @SerializedName("job_title")
    val jobTitle: String,
    @SerializedName("job_location")
    val jobLocation: String,
    @SerializedName("age")
    val minAge: Int
)