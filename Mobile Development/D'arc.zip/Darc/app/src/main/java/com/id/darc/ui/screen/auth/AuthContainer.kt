package com.id.darc.ui.screen.auth;

import androidx.compose.animation.Crossfade
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.id.darc.R
import com.id.darc.ui.component.button.PrimaryButton
import com.id.darc.ui.screen.auth.login.LoginScreen
import com.id.darc.ui.screen.auth.register.RegisterScreen
import com.id.darc.ui.screen.auth.register.RegisterSuccessScreen
import com.id.darc.ui.theme.DarcTheme
import com.id.darc.ui.theme.purple
import com.id.darc.ui.theme.white
import kotlinx.coroutines.launch


/*
   Created by Andre Eka Putra on 05/12/23
   andremoore431@gmail.com
*/

enum class Authentication {
    REGISTER, LOGIN, HOME_AUTH, SUCCESS_REGISTER
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuthContainer(
    modifier: Modifier = Modifier,
    viewModel: AuthViewModel = hiltViewModel()
) {
    val currentNav = remember { mutableStateOf(Authentication.HOME_AUTH) }
    val uiState = viewModel.uiState.collectAsState()
    val scope = rememberCoroutineScope()
    val snackBarHostState = remember { SnackbarHostState() }

    LaunchedEffect(key1 = uiState.value.isError) {
        if (uiState.value.isError) {
            scope.launch {
                snackBarHostState.showSnackbar(uiState.value.message)
            }
        }
    }
    Scaffold(
        snackbarHost = {
            SnackbarHost(hostState = snackBarHostState)
        }
    ) {innerPadding ->
        Column(
            modifier = modifier
                .padding(innerPadding)
                .background(
                    brush = Brush.linearGradient(
                        colors = listOf(
                            white, purple
                        )
                    )
                )
                .padding(horizontal = 20.dp, vertical = 40.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Crossfade(targetState = currentNav.value, label = "") {
                when (it) {
                    Authentication.REGISTER -> RegisterScreen(
                        onBackListener = {currentNav.value = Authentication.HOME_AUTH},
                        navigateToLogin = {currentNav.value = Authentication.LOGIN}
                    )
                    Authentication.LOGIN -> LoginScreen(
                        onBackListener = {currentNav.value = Authentication.HOME_AUTH},
                        navigateToRegister = {currentNav.value = Authentication.REGISTER}
                    )
                    Authentication.HOME_AUTH -> AuthScreen(
                        navigateToLogin = {currentNav.value = Authentication.LOGIN},
                        navigateToRegister = {currentNav.value = Authentication.REGISTER},
                    )
                    Authentication.SUCCESS_REGISTER -> RegisterSuccessScreen(
                        onBackListener = {currentNav.value = Authentication.HOME_AUTH},
                    )
                }
            }
        }
    }

}

@Composable
@Preview (showSystemUi = true)
fun ShowAuthContainerPreview() {
    DarcTheme {
        AuthContainer()
    }
}
