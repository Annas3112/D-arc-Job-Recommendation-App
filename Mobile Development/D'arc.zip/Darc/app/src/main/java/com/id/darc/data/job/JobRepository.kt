package com.id.darc.data.job

import com.id.darc.data.ApiResponse
import com.id.darc.data.Resource
import com.id.darc.data.job.source.JobDataSource
import com.id.darc.repository.irepository.IJobRepository
import com.id.darc.repository.model.company.CompanyDetailModel
import com.id.darc.repository.model.company.CompanyModel
import com.id.darc.repository.model.company.CompanyModelMapper.mapCompaniesResponseToModel
import com.id.darc.repository.model.company.CompanyModelMapper.mapCompaniesToDetailModel
import com.id.darc.repository.model.company.CompanyModelMapper.mapCompanyResponseToModel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flow
import javax.inject.Inject


/*
   Created by Andre Eka Putra on 22/12/23
   andremoore431@gmail.com
*/

class JobRepository @Inject constructor(
    private val jobDataSource: JobDataSource
): IJobRepository {
    override fun searchCompany(companyName: String): Flow<Resource<CompanyModel>> = flow {
        emit(Resource.Loading())
        when (val response = jobDataSource.searchCompany(companyName).first()) {
            is ApiResponse.Error -> emit(Resource.Error(response.error))
            is ApiResponse.Success -> emit(Resource.Success(mapCompanyResponseToModel(response.data.data)))
        }
    }

    override fun fetchCompanies(): Flow<Resource<List<CompanyModel>>> = flow {
        emit(Resource.Loading())
        when (val response = jobDataSource.fetchCompanies().first()) {
            is ApiResponse.Error -> emit(Resource.Error(response.error))
            is ApiResponse.Success -> emit(Resource.Success(mapCompaniesResponseToModel(response.data)))
        }
    }

    override fun fetchDetailCompany(id: Int): Flow<Resource<CompanyDetailModel>> = flow {
        emit(Resource.Loading())
        when (val response = jobDataSource.fetchCompanies().first()) {
            is ApiResponse.Error -> emit(Resource.Error(response.error))
            is ApiResponse.Success -> emit(Resource.Success(mapCompaniesToDetailModel(response.data.data[id])))
        }
    }
}