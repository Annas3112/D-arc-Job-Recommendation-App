package com.id.darc.ui.screen.auth.register;

import android.graphics.fonts.FontStyle
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.id.darc.R
import com.id.darc.ui.component.button.PrimaryButton
import com.id.darc.ui.component.field.InputTextField
import com.id.darc.ui.screen.auth.AuthViewModel
import com.id.darc.ui.theme.DarcTheme
import com.id.darc.ui.theme.primaryColor


/*
   Created by Andre Eka Putra on 05/12/23
   andremoore431@gmail.com
*/


@Composable
fun RegisterScreen(
    modifier: Modifier = Modifier,
    viewModel: AuthViewModel = hiltViewModel(),
    onBackListener: () -> Unit = {},
    navigateToLogin: () -> Unit = {}
) {
    val uiState = viewModel.uiState.collectAsStateWithLifecycle()

    val username = remember { mutableStateOf("") }
    val email = remember { mutableStateOf("") }
    val phoneNumber = remember { mutableStateOf("") }
    val password = remember { mutableStateOf("") }
    val passwordConfirm = remember { mutableStateOf("") }

    LaunchedEffect(key1 = uiState.value.isSuccess) {
        if (uiState.value.isSuccess) {
            navigateToLogin()
        }
    }

    Column {
        Icon(
            modifier = Modifier.clickable { onBackListener() },
            imageVector = Icons.Default.ArrowBack,
            contentDescription = "")
        Column(
            modifier = modifier.fillMaxSize()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Spacer(modifier = Modifier.padding(20.dp))
            Text(text = "SIGN UP", color = primaryColor,
                fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.padding(20.dp))
            InputTextField(hint = "Username", value = username.value) {
                username.value = it
            }
            Spacer(modifier = Modifier.padding(10.dp))
            InputTextField(hint = "Email", value = email.value) {
                email.value = it
            }
            Spacer(modifier = Modifier.padding(10.dp))
            InputTextField(hint = "Phone Number", value = phoneNumber.value, isPhoneInput = true) {
                phoneNumber.value = it
            }
            Spacer(modifier = Modifier.padding(10.dp))
            InputTextField(hint = "Password", hideValue = true, value = password.value) {
                password.value = it
            }
            Spacer(modifier = Modifier.padding(10.dp))
            InputTextField(hint = "Confirm Password", hideValue = true, value = passwordConfirm.value) {
                passwordConfirm.value = it
            }
            Spacer(modifier = Modifier.padding(20.dp))
            PrimaryButton(
                text = "SIGN UP",
                enable = password.value.isNotEmpty() && password.value == passwordConfirm.value,
            ) {
                viewModel.register(email = email.value, password = password.value)
            }
            Spacer(modifier = Modifier.padding(20.dp))
            Row {
                Spacer(modifier = Modifier.weight(1f))
                Text(text = "LOGIN", modifier = Modifier.clickable {
                    navigateToLogin()
                })
            }
            Spacer(modifier = Modifier.weight(1f))
            Image(
                modifier = Modifier.size(70.dp, 90.dp),
                painter = painterResource(id = R.drawable.darc_logo),
                contentDescription = "")
        }
    }
}

@Composable
@Preview(showSystemUi = true)
fun ShowRegisterScreenPreview() {
    DarcTheme {
        RegisterScreen()
    }
}
