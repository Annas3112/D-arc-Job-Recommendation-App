package com.id.darc.ui.screen.company;

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.id.darc.repository.model.company.CompanyDetailModel
import com.id.darc.ui.theme.DarcTheme
import com.id.darc.ui.theme.Typography


/*
   Created by Andre Eka Putra on 21/12/23
   andremoore431@gmail.com
*/


@Composable
fun CompanyScreen(
    modifier: Modifier = Modifier,
    companyDetailModel: CompanyDetailModel = CompanyDetailModel.fakes()[0]
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .fillMaxWidth()
            .background(Color.Gray)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Column(
            ) {
                Text(text = "Company Name", style = Typography.titleMedium)
                Text(text = companyDetailModel.profileName, style = Typography.bodyMedium)
            }
            Column(
            ) {
                Text(text = "Company Type", style = Typography.titleMedium)
                Text(text = companyDetailModel.companyType, style = Typography.bodyMedium)
            }
            Column(
            ) {
                Text(text = "Total Type", style = Typography.titleMedium)
                Text(text = companyDetailModel.totalEmployee, style = Typography.bodyMedium)
            }
            Column(
            ) {
                Text(text = "About Company", style = Typography.titleMedium)
                Text(text = companyDetailModel.aboutCompany, style = Typography.bodyMedium)
            }
        }
    }
}

@Composable
@Preview
fun ShowCompanyScreenPreview() {
    DarcTheme {
        CompanyScreen()
    }
}
