package com.id.darc.ui.screen.recommend;

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.id.darc.repository.model.company.CompanyModel
import com.id.darc.ui.component.card.CompanyCardVertical
import com.id.darc.ui.theme.DarcTheme


/*
   Created by Andre Eka Putra on 13/12/23
   andremoore431@gmail.com
*/


@Composable
fun RecommendScreen(
    modifier: Modifier = Modifier
) {
    val dummyData = CompanyModel.fakes
    Column(
        modifier = modifier
    ) {
        LazyColumn(
            contentPadding = PaddingValues(vertical = 20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(dummyData) {
                CompanyCardVertical(companyProfile = it)
            }
        }
    }
}

@Composable
@Preview
fun ShowRecommendScreenPreview() {
    DarcTheme {
        RecommendScreen()
    }
}
