package com.id.darc.repository.model.company


/*
   Created by Andre Eka Putra on 21/12/23
   andremoore431@gmail.com
*/

data class CompanyDetailModel(
    val profilePicture: String,
    val jobDesc: String,
    val profileName: String,
    val salary: String,
    val companyType : String,
    val totalEmployee: String,
    val aboutCompany: String,
    val location: String,
    val jobType: List<String>,
    val minimumGraduate: String,
    val peopleNeeds: String,
    val reqDetail: List<String>
) {
    companion object {
        fun fakes() = (1..10).map {
            CompanyDetailModel(
                profilePicture = "",
                jobDesc = "Job Desc $it",
                profileName = "Profile Name $it",
                salary = "Rp $it / month",
                location = "Location $it",
                jobType = listOf(
                    "Full time $it"
                ),
                minimumGraduate = "S$it",
                peopleNeeds = "${it} - ${it+1} Needs",
                reqDetail = listOf(
                    "Male $it",
                    "Communicative $it"
                ),
                companyType = "Bank $it",
                totalEmployee = "${140+it}",
                aboutCompany = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur $it",
            )
        }
    }
}
