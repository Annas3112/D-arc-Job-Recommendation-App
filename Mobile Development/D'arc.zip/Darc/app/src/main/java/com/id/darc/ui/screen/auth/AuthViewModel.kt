package com.id.darc.ui.screen.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.id.darc.data.Resource
import com.id.darc.data.auth.AuthRepository
import com.id.darc.repository.irepository.IAuthRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject


/*
   Created by Andre Eka Putra on 20/12/23
   andremoore431@gmail.com
*/

@HiltViewModel
class AuthViewModel @Inject constructor(
    private val authRepository: IAuthRepository
): ViewModel() {
    val _uiState = MutableStateFlow(AuthUIState())
    val uiState: StateFlow<AuthUIState> = _uiState.asStateFlow()

    fun login(email: String, password: String) {
        viewModelScope.launch {
            authRepository.login(email, password).collect {
                when (it) {
                    is Resource.Error -> handleError(it.message.toString())
                    is Resource.Loading -> {}
                    is Resource.Success -> handleSuccess()
                }
            }
        }
    }

    fun register(email: String, password: String) {
        viewModelScope.launch {
            authRepository.register(email, password).collect {
                when (it) {
                    is Resource.Error -> handleError(it.message.toString())
                    is Resource.Loading -> {}
                    is Resource.Success -> handleSuccess()
                }
            }
        }
    }
}