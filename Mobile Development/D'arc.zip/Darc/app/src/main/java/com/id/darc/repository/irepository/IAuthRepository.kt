package com.id.darc.repository.irepository

import com.id.darc.data.Resource
import com.id.darc.data.auth.response.RegisterResponse
import kotlinx.coroutines.flow.Flow

interface IAuthRepository {
    fun login(email: String, password: String): Flow<Resource<RegisterResponse>>
    fun register(email: String, password: String): Flow<Resource<RegisterResponse>>
    fun logout()
}