package com.id.darc.ui.screen.auth.register;

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.id.darc.R
import com.id.darc.ui.theme.DarcTheme
import com.id.darc.ui.theme.white


/*
   Created by Andre Eka Putra on 05/12/23
   andremoore431@gmail.com
*/


@Composable
fun RegisterSuccessScreen(
    modifier: Modifier = Modifier,
    onBackListener: () -> Unit = {}
) {
    Column {
        Icon(
            modifier = Modifier.clickable { onBackListener() },
            imageVector = Icons.Default.ArrowBack,
            contentDescription = "")
        Column(
            modifier = modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "Successfully Created Your Find Job Account ",
                style = TextStyle(
                    fontSize = 21.sp,
                    textAlign = TextAlign.Center,
                )
            )
            Spacer(modifier = Modifier.height(50.dp))
            Image(
                painter = painterResource(id = R.drawable.success),
                contentDescription = "image description",
                contentScale = ContentScale.Crop
            )
            Spacer(modifier = Modifier.height(50.dp))
            Text(
                text = "You have successfully created \nyour Find Job account. \nNow you can search for job applications \nfrom various fields and various cities.",
                style = TextStyle(
                    fontSize = 15.sp,
                    color = white,
                    textAlign = TextAlign.Center,
                )
            )
            Spacer(modifier = Modifier.height(150.dp))
            Image(
                modifier = Modifier.size(70.dp, 90.dp),
                painter = painterResource(id = R.drawable.darc_logo),
                contentDescription = "")
        }
    }
}

@Composable
@Preview(showSystemUi = true)
fun ShowRegisterSuccessScreenPreview() {
    DarcTheme {
        RegisterSuccessScreen()
    }
}
