package com.id.darc.ui.screen.activity;

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.id.darc.repository.model.company.CompanyModel
import com.id.darc.ui.component.card.CompanyCardVertical
import com.id.darc.ui.component.card.CompanycardApplied
import com.id.darc.ui.theme.DarcTheme


/*
   Created by Andre Eka Putra on 21/12/23
   andremoore431@gmail.com
*/


@Composable
fun AppliedScreen(
    modifier: Modifier = Modifier
) {
    val dummyCompanyData = CompanyModel.fakes

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(15.dp),
        contentPadding = PaddingValues(20.dp)
    ) {
        items(dummyCompanyData) {
            CompanycardApplied(companyProfile = it)
        }
    }
}

@Composable
@Preview
fun ShowAppliedScreenPreview() {
    DarcTheme {
        AppliedScreen()
    }
}
