package com.id.darc.data


/*
   Created by Andre Eka Putra on 20/12/23
   andremoore431@gmail.com
*/

sealed class ApiResponse<out R> {
    data class Success<out T>(val data: T) : ApiResponse<T>()
    data class Error(val error: String): ApiResponse<Nothing>()
}