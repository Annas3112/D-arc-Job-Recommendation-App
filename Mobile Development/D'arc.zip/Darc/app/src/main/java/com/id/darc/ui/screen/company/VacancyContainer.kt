package com.id.darc.ui.screen.company;

import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.id.darc.R
import com.id.darc.repository.model.company.CompanyDetailModel
import com.id.darc.ui.component.button.PrimaryButton
import com.id.darc.ui.theme.DarcTheme
import com.id.darc.ui.theme.Typography


/*
   Created by Andre Eka Putra on 21/12/23
   andremoore431@gmail.com
*/


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VacancyContainer(
    modifier: Modifier = Modifier,
    backNavigation: () -> Unit = {},
    companyDetailModel: CompanyDetailModel = CompanyDetailModel.fakes()[0],
    itemIndex: Int = 0,
) {
    var state by remember { mutableIntStateOf(0) }
    val titles = listOf("Details", "Company")
    val viewModel: VacancyViewModel = hiltViewModel()
    val uiState = viewModel.uiState.collectAsStateWithLifecycle()


    LaunchedEffect(key1 = Unit) {
        viewModel.jobRepository(itemIndex)
    }
    Scaffold(
        modifier = Modifier.background(Color.LightGray),
        topBar = {
            TopAppBar(
                title = {
                    Text(text ="Detail Vacancy", style = Typography.titleLarge)
                },
                navigationIcon = {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = null, modifier = Modifier
                        .padding(20.dp)
                        .clickable {
                            backNavigation()
                        })
                }
            )
        }
    ) {innerPadding ->
        Column(
            modifier = modifier
                .padding(innerPadding)
                .padding(20.dp)
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Image(painter = painterResource(id = R.drawable.pertamina_dummy_picture),
                    contentDescription = null, modifier = Modifier.size(120.dp, 90.dp))
                Column {
                    Text(text = uiState.value.data.jobTitle, style = Typography.titleLarge)
                    Text(text = uiState.value.data.profileName, style = Typography.bodyLarge)
                }
                Spacer(modifier = Modifier.weight(1f))
                Icon(painter = painterResource(id = R.drawable.bookmark_unfilled), contentDescription = null,
                    modifier = Modifier.size(20.dp)
                )
            }
            TabRow(selectedTabIndex = state, modifier = Modifier.padding(bottom = 20.dp)) {
                titles.forEachIndexed { index, title ->
                    Tab(
                        selected = state == index,
                        onClick = { state = index },
                        text = { Text(text = title, maxLines = 2, overflow = TextOverflow.Ellipsis) }
                    )
                }
            }
            when (state) {
                0 -> DetailScreen(companyDetailModel = uiState.value.data)
                1 -> CompanyScreen(companyDetailModel = uiState.value.data)
            }
            PrimaryButton(
                text = "Apply Now",
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 30.dp, vertical = 20.dp)
            ) {

            }
        }
    }

}

@Composable
@Preview
fun ShowVacancyContainerPreview() {
    DarcTheme {
        VacancyContainer()
    }
}
