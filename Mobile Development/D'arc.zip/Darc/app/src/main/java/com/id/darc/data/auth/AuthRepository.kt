package com.id.darc.data.auth

import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import com.id.darc.data.Resource
import com.id.darc.data.auth.response.RegisterResponse
import com.id.darc.repository.irepository.IAuthRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.tasks.await
import javax.inject.Inject


/*
   Created by Andre Eka Putra on 20/12/23
   andremoore431@gmail.com
*/

class AuthRepository @Inject constructor(

): IAuthRepository {
    private var auth = Firebase.auth

    override fun register(email: String, password: String): Flow<Resource<RegisterResponse>> = flow {
        emit(Resource.Loading())

        try {
            val authResult = auth.createUserWithEmailAndPassword(email, password).await()
            // Check if the user registration was successful
            if (authResult.user != null) {
                emit(Resource.Success(RegisterResponse(isError = false, message = "User Created")))
            } else {
                emit(Resource.Error("User registration failed"))
            }
        } catch (e: Exception) {
            // Handle exceptions during user registration
            emit(Resource.Error(e.message.toString()))
        }
    }.flowOn(Dispatchers.IO)

    override fun logout() {
        auth.signOut()
    }

    override fun login(email: String, password: String): Flow<Resource<RegisterResponse>> = flow {
        emit(Resource.Loading())

        try {
            val authResult = auth.signInWithEmailAndPassword(email, password).await()
            // Check if the user registration was successful
            if (authResult.user != null) {
                emit(Resource.Success(RegisterResponse(isError = false, message = "User Created")))
            } else {
                emit(Resource.Error("User registration failed"))
            }
        } catch (e: Exception) {
            // Handle exceptions during user registration
            emit(Resource.Error(e.message.toString()))
        }
    }.flowOn(Dispatchers.IO)

}