package com.id.darc.repository.model.company

import com.id.darc.data.job.response.SearchCompanyDataResponse


/*
   Created by Andre Eka Putra on 22/12/23
   andremoore431@gmail.com
*/

object CompanyModelMapper {
    fun mapCompanyResponseToModel(companyResponse: SearchCompanyDataResponse?): CompanyModel {
        return CompanyModel(
            profilePicture = "",
            name = companyResponse?.companyName ?: "",
            position = "",
            location = "",
            requirement = "",
            salary = "",
            bookmark = false

        )
    }
}