package com.id.darc.repository.model.company

import com.id.darc.data.job.response.CompaniesResponse
import com.id.darc.data.job.response.CompanyDataResponse
import com.id.darc.data.job.response.SearchCompanyDataResponse


/*
   Created by Andre Eka Putra on 22/12/23
   andremoore431@gmail.com
*/

object CompanyModelMapper {
    fun mapCompanyResponseToModel(companyResponse: SearchCompanyDataResponse?): CompanyModel {
        return CompanyModel(
            profilePicture = "",
            name = companyResponse?.companyName ?: "",
            position = "",
            location = "",
            requirement = "",
            salary = "",
            bookmark = false

        )
    }

    fun mapCompaniesResponseToModel(companyResponse: CompaniesResponse): List<CompanyModel> {
        return companyResponse.data.map {
            mapCompanyResponseToModel(it)
        }
    }

    fun mapCompanyResponseToModel(companyResponse: CompanyDataResponse): CompanyModel {
        return CompanyModel(
            profilePicture = "",
            name = companyResponse.company,
            position = companyResponse.jobTitle,
            location = companyResponse.jobLocation,
            requirement = companyResponse.education,
            salary = companyResponse.maxSalary.toString(),
            bookmark = false
        )
    }

    fun mapCompaniesToDetailModel(it: CompanyDataResponse): CompanyDetailModel {
        return CompanyDetailModel(
            profilePicture = "",
            jobDesc = it.jobDesc,
            profileName = it.company,
            salary = it.maxSalary.toString(),
            companyType = "",
            totalEmployee = "",
            aboutCompany = "",
            location = it.jobLocation,
            jobType = listOf(it.jobStatus),
            minimumGraduate = it.education,
            peopleNeeds = "",
            reqDetail = listOf(it.skillSet),
            jobTitle = it.jobTitle
        )
    }
}