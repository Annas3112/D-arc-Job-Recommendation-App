package com.id.darc.ui.screen

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await


/*
   Created by Andre Eka Putra on 20/12/23
   andremoore431@gmail.com
*/
class UIViewModel: ViewModel() {
    val _uiState = MutableStateFlow(ContainerUIState())
    val uiState: StateFlow<ContainerUIState> = _uiState.asStateFlow()

    private val auth = Firebase.auth

    init {
        // Add an AuthStateListener to update the _isLogin LiveData when the authentication state changes
        auth.addAuthStateListener { firebaseAuth ->
            val user = firebaseAuth.currentUser
            changeUserLogin(user!=null)
        }
    }

    override fun onCleared() {
        super.onCleared()
        // Remove the AuthStateListener when the ViewModel is cleared (e.g., when the associated UI component is destroyed)
        auth.removeAuthStateListener { /* your AuthStateListener here */ }
    }
}

data class ContainerUIState(
    val isLogin: Boolean = false
)

fun UIViewModel.changeUserLogin(isLogin: Boolean) {
    _uiState.update {
        it.copy(
            isLogin = isLogin
        )
    }
}