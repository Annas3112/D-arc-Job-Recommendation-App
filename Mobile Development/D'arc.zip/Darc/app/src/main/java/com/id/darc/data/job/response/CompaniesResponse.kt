package com.id.darc.data.job.response

import com.google.gson.annotations.SerializedName


/*
   Created by Andre Eka Putra on 26/12/23
   andremoore431@gmail.com
*/

data class CompaniesResponse(
    @SerializedName("error")
    val error: Boolean,
    @SerializedName("message")
    val message: String,
    @SerializedName("data")
    val data: List<CompanyDataResponse>
)
