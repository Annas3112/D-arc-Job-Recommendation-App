package com.id.darc.ui.component.field;

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.tooling.preview.Preview
import com.id.darc.ui.theme.DarcTheme
import com.id.darc.ui.theme.Typography


/*
   Created by Andre Eka Putra on 13/12/23
   andremoore431@gmail.com
*/


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InputTextFieldLeading(
    modifier: Modifier = Modifier,
    enable: Boolean = true,
    value: String = "",
    text: String = "",
    onValueChange: (String) -> Unit = {}
) {
    OutlinedTextField(
        modifier = modifier.fillMaxWidth(),
        value = value,
        maxLines = 1,
        onValueChange = onValueChange,
        keyboardOptions = KeyboardOptions(
            imeAction = ImeAction.Done
        ),
        label = {
            Text(text = text, style = Typography.bodyMedium)
        },
        enabled = enable,
        leadingIcon = {
            Icon(imageVector = Icons.Default.Search, contentDescription = null)
        }
    )
}

@Composable
@Preview
fun ShowInputTextFieldLeadingPreview() {
    DarcTheme {
        InputTextFieldLeading(
            value = "",
            text = "Search",
            onValueChange = {}
        )
    }
}
