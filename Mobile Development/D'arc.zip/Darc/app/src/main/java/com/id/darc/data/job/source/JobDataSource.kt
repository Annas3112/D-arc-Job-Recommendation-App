package com.id.darc.data.job.source

import com.id.darc.data.ApiResponse
import com.id.darc.data.job.response.SearchCompanyResponse
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import javax.inject.Inject


/*
   Created by Andre Eka Putra on 22/12/23
   andremoore431@gmail.com
*/

class JobDataSource @Inject constructor(
    private val jobApiService: JobApiService
) {
    fun searchCompany(company: String): Flow<ApiResponse<SearchCompanyResponse>> = flow {
        emit(try {
            val response = jobApiService.getCompanyByName(companyName = company)
            when (response.error) {
                true -> throw TypeCastException()
                false -> ApiResponse.Success(response)
            }
        } catch (e: Exception) {
            ApiResponse.Error(e.message.toString())
        })
    }
}