package com.id.darc.ui.screen;

import androidx.compose.animation.Crossfade
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.hilt.navigation.compose.hiltViewModel
import com.id.darc.ui.screen.auth.AuthContainer
import com.id.darc.ui.screen.home.HomeContainer
import com.id.darc.ui.screen.splash.SplashContainer
import com.id.darc.ui.theme.DarcTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.lang.Thread.sleep


/*
   Created by Andre Eka Putra on 05/12/23
   andremoore431@gmail.com
*/


@Composable
fun UIContainer(
    modifier: Modifier = Modifier,
    viewModel: UIViewModel = hiltViewModel()
) {
    val showSplash = remember { mutableStateOf(true) }

    val uiState = viewModel.uiState.collectAsState()

    LaunchedEffect(Unit) {
        delay(1500)
        showSplash.value = false
    }
    
    Crossfade(targetState = showSplash.value, label = "") {
        when (it) {
            true -> SplashContainer()
            false -> when (uiState.value.isLogin) {
                true -> HomeContainer()
                false -> AuthContainer()
            }
        }
    }
}

@Composable
@Preview
fun ShowUIContainerPreview() {
    DarcTheme {
        UIContainer()
    }
}
