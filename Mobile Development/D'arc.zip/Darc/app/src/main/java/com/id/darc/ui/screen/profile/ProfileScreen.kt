package com.id.darc.ui.screen.profile;

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import coil.compose.AsyncImage
import com.id.darc.ui.component.button.PrimaryButton
import com.id.darc.ui.component.field.InputTextField
import com.id.darc.ui.theme.DarcTheme
import com.id.darc.ui.theme.Typography


/*
   Created by Andre Eka Putra on 20/12/23
   andremoore431@gmail.com
*/


@Composable
fun ProfileScreen(
    modifier: Modifier = Modifier,
    viewModel: ProfileViewModel = hiltViewModel()
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 20.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(30.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AsyncImage(model = "", contentDescription = null,
                modifier = Modifier
                    .size(126.dp, 113.dp)
                    .clip(CircleShape)
            )
            Column {
                Text(text = "Angel Visoya ", style = Typography.bodyLarge)
                Text(text = "Undergraduate Informatics Engineering Students, University of Lampung", style = Typography.bodyMedium)
                Row {
                    Icon(imageVector = Icons.Default.LocationOn, contentDescription = null)
                    Text(text = "Bandar Lampung City, Lampung", style = Typography.bodyMedium)
                }
            }
        }
        Column(
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            InputTextField(hint = "FullName",
                value = "",
                onValueChange = {}
            )
            InputTextField(hint = "NickName",
                value = "",
                onValueChange = {}
            )
            InputTextField(hint = "Date of Birth",
                value = "",
                onValueChange = {}
            )
            InputTextField(hint = "Gender",
                value = "",
                onValueChange = {}
            )
            InputTextField(hint = "Email",
                value = "",
                onValueChange = {}
            )
            InputTextField(hint = "Phone Number",
                value = "",
                onValueChange = {}
            )
            InputTextField(hint = "Whatsapp Number",
                value = "",
                onValueChange = {}
            )
        }
        Column(
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            InputTextField(hint = "Province",
                value = "",
                onValueChange = {}
            )
            InputTextField(hint = "Regency",
                value = "",
                onValueChange = {}
            )
            InputTextField(hint = "Subdistrict",
                value = "",
                onValueChange = {}
            )
        }
        Column(
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            InputTextField(hint = "Educational Level",
                value = "",
                onValueChange = {}
            )
            InputTextField(hint = "School/College*",
                value = "",
                onValueChange = {}
            )
            InputTextField(hint = "Majors Courses",
                value = "",
                onValueChange = {}
            )
            InputTextField(hint = "Start Education",
                value = "",
                onValueChange = {}
            )
            InputTextField(hint = "Graduated from Education",
                value = "",
                onValueChange = {}
            )
        }
        PrimaryButton(text = "LOGOUT") {
            viewModel.logout()

        }
    }
}

@Composable
@Preview(showSystemUi = true)
fun ShowProfileScreenPreview() {
    DarcTheme {
        ProfileScreen()
    }
}
