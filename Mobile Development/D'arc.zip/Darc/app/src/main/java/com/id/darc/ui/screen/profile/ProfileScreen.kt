package com.id.darc.ui.screen.profile;

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import coil.compose.AsyncImage
import com.id.darc.ui.component.button.PrimaryButton
import com.id.darc.ui.component.field.InputTextField
import com.id.darc.ui.theme.DarcTheme
import com.id.darc.ui.theme.Typography


/*
   Created by Andre Eka Putra on 20/12/23
   andremoore431@gmail.com
*/


@Composable
fun ProfileScreen(
    modifier: Modifier = Modifier,
    viewModel: ProfileViewModel = hiltViewModel()
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 20.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(30.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AsyncImage(model = "", contentDescription = null,
                modifier = Modifier
                    .size(126.dp, 113.dp)
                    .clip(CircleShape)
            )
            Column {
                Text(text = "Angel Visoya ", style = Typography.bodyLarge)
                Text(text = "Undergraduate Informatics Engineering Students, University of Lampung", style = Typography.bodyMedium)
                Row {
                    Icon(imageVector = Icons.Default.LocationOn, contentDescription = null)
                    Text(text = "Bandar Lampung City, Lampung", style = Typography.bodyMedium)
                }
            }
        }
        var fullName by remember { mutableStateOf("") }
        var nickName by remember { mutableStateOf("") }
        var dob by remember { mutableStateOf("") }
        var gender by remember { mutableStateOf("") }
        var email by remember { mutableStateOf("") }
        var phoneNumber by remember { mutableStateOf("") }
        var whatsappNumber by remember { mutableStateOf("") }

        var province by remember { mutableStateOf("") }
        var regency by remember { mutableStateOf("") }
        var subdistrict by remember { mutableStateOf("") }

        var educationalLevel by remember { mutableStateOf("") }
        var schoolCollege by remember { mutableStateOf("") }
        var majorsCourses by remember { mutableStateOf("") }
        var startEducation by remember { mutableStateOf("") }
        var graduatedEducation by remember { mutableStateOf("") }

        Column(
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            InputTextField(hint = "FullName",
                value = fullName,
                onValueChange = { fullName = it }
            )
            InputTextField(hint = "NickName",
                value = nickName,
                onValueChange = { nickName = it }
            )
            InputTextField(hint = "Date of Birth",
                value = dob,
                onValueChange = { dob = it }
            )
            InputTextField(hint = "Gender",
                value = gender,
                onValueChange = { gender = it }
            )
            InputTextField(hint = "Email",
                value = email,
                onValueChange = { email = it }
            )
            InputTextField(hint = "Phone Number",
                value = phoneNumber,
                onValueChange = { phoneNumber = it }
            )
            InputTextField(hint = "Whatsapp Number",
                value = whatsappNumber,
                onValueChange = { whatsappNumber = it }
            )
        }
        Column(
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            InputTextField(hint = "Province",
                value = province,
                onValueChange = { province = it }
            )
            InputTextField(hint = "Regency",
                value = regency,
                onValueChange = { regency = it }
            )
            InputTextField(hint = "Subdistrict",
                value = subdistrict,
                onValueChange = { subdistrict = it }
            )
        }
        Column(
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            InputTextField(hint = "Educational Level",
                value = educationalLevel,
                onValueChange = { educationalLevel = it }
            )
            InputTextField(hint = "School/College*",
                value = schoolCollege,
                onValueChange = { schoolCollege = it }
            )
            InputTextField(hint = "Majors Courses",
                value = majorsCourses,
                onValueChange = { majorsCourses = it }
            )
            InputTextField(hint = "Start Education",
                value = startEducation,
                onValueChange = { startEducation = it }
            )
            InputTextField(hint = "Graduated from Education",
                value = graduatedEducation,
                onValueChange = { graduatedEducation = it }
            )
        }
        PrimaryButton(text = "LOGOUT") {
            viewModel.logout()

        }
    }
}

@Composable
@Preview(showSystemUi = true)
fun ShowProfileScreenPreview() {
    DarcTheme {
        ProfileScreen()
    }
}
