package com.id.darc.data.job.response

import com.google.gson.annotations.SerializedName

data class SearchCompanyResponse(
    @SerializedName("error")
    val error: Boolean,
    @SerializedName("message")
    val message: String,
    @SerializedName("data")
    val data: SearchCompanyDataResponse?
)
