package com.id.darc.data.job.response

import com.google.gson.annotations.SerializedName


/*
   Created by Andre Eka Putra on 22/12/23
   andremoore431@gmail.com
*/

data class SearchCompanyResponse(
    @SerializedName("error")
    val error: Boolean,
    @SerializedName("message")
    val message: String,
    @SerializedName("data")
    val data: SearchCompanyDataResponse?
)
