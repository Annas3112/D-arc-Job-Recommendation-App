package com.id.darc.data.job.source

import com.id.darc.data.job.response.SearchCompanyResponse
import retrofit2.http.GET
import retrofit2.http.Path


/*
   Created by Andre Eka Putra on 22/12/23
   andremoore431@gmail.com
*/

interface JobApiService {
    @GET("getCompanyByName/{companyName}")
    suspend fun getCompanyByName(@Path("companyName") companyName: String): SearchCompanyResponse
}