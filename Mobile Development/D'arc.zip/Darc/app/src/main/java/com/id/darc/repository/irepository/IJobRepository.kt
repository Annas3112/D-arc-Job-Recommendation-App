package com.id.darc.repository.irepository

import com.id.darc.data.Resource
import com.id.darc.repository.model.company.CompanyModel
import kotlinx.coroutines.flow.Flow


/*
   Created by Andre Eka Putra on 22/12/23
   andremoore431@gmail.com
*/

interface IJobRepository {
    fun searchCompany(companyName: String): Flow<Resource<CompanyModel>>
}